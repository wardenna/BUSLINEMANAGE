create PROCEDURE searchByStation(
  start_Station IN VARCHAR2,
  end_Station   IN VARCHAR2,
  cur3          OUT SYS_REFCURSOR
)
IS
  cur1 SYS_REFCURSOR;
  cur2 SYS_REFCURSOR;
  busLineId1 VARCHAR2(20);
  busLineId2 VARCHAR2(20);
  BEGIN
    OPEN cur3 FOR SELECT * FROM busLine WHERE start_Station = startStation AND end_Station = endStation;
    CLOSE cur3;
  END;