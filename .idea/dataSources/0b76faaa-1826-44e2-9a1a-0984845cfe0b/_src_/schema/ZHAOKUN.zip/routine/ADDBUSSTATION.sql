create PROCEDURE addBusStation(
  busLine_Id         IN VARCHAR2,
  busStation_Name    IN VARCHAR2,
  arrival_Time       IN VARCHAR2,
  seq_Number         IN VARCHAR2,
  start_Station      IN VARCHAR2,
  end_Station        IN VARCHAR2,
  busStation_remarks IN VARCHAR2
)
IS
  BEGIN
    INSERT INTO busStation (busStationId, busLineId, busStationName, arrivalTime, startStation, endStation, seqNumber, REMARKS)
    VALUES (SEQ_ID.nextval, busLine_Id, busStation_Name, arrival_Time, start_Station, end_Station, seq_Number,
            busStation_remarks);
  END;